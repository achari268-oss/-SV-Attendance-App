const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    message: "SV Attendance SMS Server is running"
  });
});

app.post("/send-sms", async (req, res) => {
  const { phone, message } = req.body;

  if (!phone || !message) {
    return res.status(400).json({
      success: false,
      message: "Phone number and message are required"
    });
  }

  // SMS provider will be connected here in the next step.
  console.log("SMS request:", { phone, message });

  res.json({
    success: true,
    message: "SMS request received"
  });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`SV Attendance SMS Server running on port ${PORT}`);
});